@can('kyc-action')
    <span data-bs-toggle="tooltip" title="" data-bs-placement="top" data-bs-original-title="View KYC Details">
  <button
      class="round-icon-btn primary-btn"
      type="button"
      id="action-kyc"
      data-id="{{$id}}"
  >
    <i icon-name="eye"></i>
  </button>
</span>
    <script>
      'use strict';
      lucide.createIcons();
    </script>
@endcan


