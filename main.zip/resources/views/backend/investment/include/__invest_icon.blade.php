<img class="avatar-icon" src="{{ asset($schema['icon']) }}" alt="">

