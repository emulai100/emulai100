<?php

return array(
    'key' => 'key',
);
