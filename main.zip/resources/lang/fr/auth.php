<?php

return array(
    'failed' => 'Ces informations d\'identification ne correspondent pas à nos enregistrements',
    'password' => 'Le mot de passe est incorrect',
    'throttle' => 'Trop de tentatives de connexion. Veuillez réessayer dans : seconds secondes.',
);
