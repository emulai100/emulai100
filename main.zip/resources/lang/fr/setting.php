<?php

return array(
    'add' => 'Ajouter maintenant',
);
