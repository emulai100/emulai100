<?php

return array(
    'reset' => '¡Tu contraseña ha sido restablecida!',
    'sent' => '¡Le hemos enviado por correo electrónico su enlace de restablecimiento de contraseña!',
    'throttled' => 'Espere antes de volver a intentarlo.',
    'token' => 'Este token de restablecimiento de contraseña no es válido.',
    'user' => 'No podemos encontrar un usuario con esa dirección de correo electrónico.',
);
