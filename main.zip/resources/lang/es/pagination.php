<?php

return array(
    'next' => 'Siguiente &raquo;La contraseña proporcionada es incorrecta',
    'previous' => '&laquo; Anterior',
);
