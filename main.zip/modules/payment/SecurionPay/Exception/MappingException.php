<?php
namespace SecurionPay\Exception;

class MappingException extends \Exception
{
}
